ALTIN & GÜMÜŞ HESAPLAYICI - ANDROID PROJESİ

Bu paket Android uygulamasının kaynak projesidir. İçinde önceki hesaplayıcının çevrimdışı çalışan ekranı bulunur.

ÖZELLİKLER
- Altın: 8, 9, 14, 18, 21, 22 ve 24 ayar
- Gümüş: 800, 900, 925 ve 999 saflık
- Özel saflık değeri
- Saf maden gram fiyatı, ürün gramı ve işçilikle tahmini alış hesabı
- Bütçeye göre alınabilecek yaklaşık gram hesabı
- İnternet izni istemez; hesaplamalar telefonda yapılır.

APK NASIL ALINIR?
Bu ZIP içinde .github/workflows/build-apk.yml dosyası vardır. GitHub Actions üzerinden bulutta APK derlemesini otomatikleştirmek için hazırlanmıştır.
1. ZIP'i açıp içindeki dosyaları bir GitHub deposuna yükleyin.
2. Depoda Actions sekmesine girin.
3. Build Android APK iş akışını seçip Run workflow'a basın (veya main dalına yükleme yapın).
4. İşlem tamamlanınca çalışmanın Artifacts bölümünden AltinGumusHesaplayici-debug-apk dosyasını indirin.
5. İndirilen artifact ZIP'ini açın; app-debug.apk dosyasını Samsung telefona gönderip kurun.

ÖNEMLİ SINIRLAMA
Bu çalışma ortamında Android SDK/Gradle derleyicisi bulunmadığından APK bu oturumda derlenip test edilemedi. Bu nedenle burada APK varmış gibi sunulmuyor. Bu paket, bulutta derleme adımını otomatikleştiren Android kaynak projesidir.
